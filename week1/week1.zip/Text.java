public interface Text {
    void append(Text txt);
}
public class TestQuicksort {

	public static void main(String[] args) {

		// Einlesen der Filme
		String file1 = "filme1.dat";
		String file2 = "filme2.dat";
		String file3 = "filme3.dat";
		Film[] f1 = Parser.readFilme(file1);
		Film[] f2 = Parser.readFilme(file2);
		Film[] f3 = Parser.readFilme(file3);

		// TODO: Testen Sie hier Ihren Quicksort-Algorithmus
		
	}
}
